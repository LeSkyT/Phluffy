<?php

namespace Twig\Error;

class_exists('Twig_Error_Loader');

if (\false) {
    class LoaderError extends \Twig_Error_Loader
    {
    }
}
