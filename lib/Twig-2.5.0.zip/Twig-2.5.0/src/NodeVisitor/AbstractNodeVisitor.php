<?php

namespace Twig\NodeVisitor;

class_exists('Twig_BaseNodeVisitor');

if (\false) {
    class AbstractNodeVisitor extends \Twig_BaseNodeVisitor
    {
    }
}
