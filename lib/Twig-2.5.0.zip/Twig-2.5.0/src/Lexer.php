<?php

namespace Twig;

class_exists('Twig_Lexer');

if (\false) {
    class Lexer extends \Twig_Lexer
    {
    }
}
