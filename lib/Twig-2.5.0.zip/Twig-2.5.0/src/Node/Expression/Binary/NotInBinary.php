<?php

namespace Twig\Node\Expression\Binary;

class_exists('Twig_Node_Expression_Binary_NotIn');

if (\false) {
    class NotInBinary extends \Twig_Node_Expression_Binary_NotIn
    {
    }
}
