<?php

namespace Twig\Node\Expression\Test;

class_exists('Twig_Node_Expression_Test_Defined');

if (\false) {
    class DefinedTest extends \Twig_Node_Expression_Test_Defined
    {
    }
}
