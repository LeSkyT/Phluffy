<?php

declare(strict_types=1);

namespace TestDocuments;

class PartialFilterDocument
{
    protected $id;
}
