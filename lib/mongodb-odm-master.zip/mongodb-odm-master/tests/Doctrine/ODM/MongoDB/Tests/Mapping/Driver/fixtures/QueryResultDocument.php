<?php

declare(strict_types=1);

namespace TestDocuments;

class QueryResultDocument
{
    public $name;

    public $count;
}
