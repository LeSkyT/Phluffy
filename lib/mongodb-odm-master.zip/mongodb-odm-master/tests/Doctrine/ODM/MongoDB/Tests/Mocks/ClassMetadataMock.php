<?php

declare(strict_types=1);

namespace Doctrine\ODM\MongoDB\Tests\Mocks;

use Doctrine\ODM\MongoDB\Mapping\ClassMetadata;

class ClassMetadataMock extends ClassMetadata
{
}
