<?php

declare(strict_types=1);

namespace TestDocuments;

class InvalidPartialFilterDocument
{
    protected $id;
}
