<?php

declare(strict_types=1);

namespace TestDocuments;

class EmbeddedDocument
{
    public $name;
}
