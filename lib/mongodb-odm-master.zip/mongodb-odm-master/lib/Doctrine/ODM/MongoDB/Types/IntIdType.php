<?php

declare(strict_types=1);

namespace Doctrine\ODM\MongoDB\Types;

/**
 * The Integer Id type.
 *
 */
class IntIdType extends IntType
{
}
