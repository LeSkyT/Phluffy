<?php

declare(strict_types=1);

namespace Doctrine\ODM\MongoDB\Proxy;

use Doctrine\Common\Proxy\Proxy as BaseProxy;

/**
 * Document Proxy interface.
 *
 */
interface Proxy extends BaseProxy
{
}
