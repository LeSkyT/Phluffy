<?php

declare(strict_types=1);

namespace Doctrine\ODM\MongoDB\Mapping\Annotations;

/** @Annotation */
final class QueryResultDocument extends AbstractDocument
{
}
